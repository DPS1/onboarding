import React from 'react';
import 'jquery/dist/jquery.min';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap/dist/css/bootstrap.min.css';
import SignUp from "./modules/sign-up/sign-up";
import './App.css';
function App() {
  return (
    <SignUp></SignUp>
  );
}

export default App;
