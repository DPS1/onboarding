import React from 'react';
import './verification.css';

class Verification extends React.Component {
    constructor(props) {
        super(props);
        this.state = {digit1: '', digit2: '', digit3: '', digit4: '', digit5: '', digit6: ''};
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    handleSubmit(event) {
        event.preventDefault();
        const verificationHandler = this.state.digit1 + this.state.digit2 + this.state.digit3 + this.state.digit4 + this.state.digit5 + this.state.digit6;
        this.props.verificationHandler(verificationHandler);
    }
    handleChange(event) {
        const fieldName = event.target.name;
        const fieldValue = event.target.value;
        this.setState({[fieldName]: fieldValue});
    }
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-12 researcher">Check your email!</div>
                    <div className="col-12 study">
                        We’ve <span style={{color: '#14B8D4' }}>sent</span> you a 6-digit confirmation code to
                        davids@materialszone.zone
                        It will expire shortly, so be quick to enter it.
                    </div>
                </div>
                <form onSubmit={this.handleSubmit}>
                    <div className="row email">
                        <div className="offset-1 col-5">
                            <div className="row input-group" style={{columnGap: 0 + '!important'}}>
                                <div className=" col-4 verif padding-0">
                                    <input type="text" maxLength="1" className="inputs inputStyle"
                                           value={this.state.digit1} onChange={this.handleChange} name='digit1'/>
                                </div>
                                <div className="col-4 verif padding-0">
                                    <input type="text" className="inputs2 inputStyle"
                                           value={this.state.digit2} onChange={this.handleChange} name='digit2'/>
                                </div>
                                <div className=" col-4 verif padding-0">
                                    <input type="text" maxLength="1" className="inputs3 inputStyle"
                                           value={this.state.digit3} onChange={this.handleChange} name='digit3'/>
                                </div>
                            </div>
                        </div>
                        <div className="col-1 middle">-</div>
                        <div className="col-5">
                            <div className="row input-group" style={{columnGap: 0 + '!important'}}>
                                <div className=" col-4 verif padding-0">
                                    <input type="text" maxLength="1" className="inputs4 inputStyle"
                                           value={this.state.digit4} onChange={this.handleChange} name='digit4'/>
                                </div>
                                <div className="col-4 verif padding-0">
                                    <input type="text" style={{width: 100 + '%'}} maxLength="1" className="inputs5"
                                           value={this.state.digit5} onChange={this.handleChange} name='digit5'/>
                                </div>
                                <div className="col-4 verif padding-0">
                                    <input type="text" maxLength="1" className="inputs6 inputStyle"
                                           value={this.state.digit6} onChange={this.handleChange} name='digit6'/>
                                </div>
                            </div>
                        </div>
                        <div className='col-lg-12' style={{textAlign: 'center', marginTop: 30 + 'px'}}>
                            <input type="submit" className="input submit" value="Verify"/>
                            {/*<button className='btn btn-primary' type='submit'>Verify</button>*/}
                        </div>
                        <br/>
                        <div className="col-12 email-info">
                            keep this window open while checking for your code.
                            <br/> Remember to try your spam folder!
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}
export default Verification;