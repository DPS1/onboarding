import React from 'react';
import './work.css';

class WorkComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state={works: ['Batteries', 'Photovoltaics', 'Smart Screens', 'Current Voltage Scans', 'Microstructures',
            'Optical Properties', 'Biologically-derived', 'Etching', 'Film Deposition', 'Fuel Cells', 'Sheet Resistance',
            'Rapid Properties', 'Microwaves', 'Solar Fuels', 'Smart Surfaces'], selectedWorks: [],
            work: {company: null, departments: null, topics: '', position: ''}}
    }
    setUserWork= () => {
        if( this.state.selectedWorks.length >= 1){
            this.props.action('work');
        }else{
            alert('please select at least 1 or more to continue');
        }
    }
    selectWork(work, selected){
        if( selected ){
            this.state.selectedWorks.splice(this.state.selectedWorks.indexOf(work), 1);
        }else{
            this.state.selectedWorks.push(work)
        }
        this.setState({selectedWorks: this.state.selectedWorks});
        const workObject = this.state.work;
        workObject.topics = this.state.selectedWorks.toString();
        this.props.handleChange({target: {name: 'work', value: workObject}});
    }



    render() {
        const usersWorks  = this.state.works.map((work, index)=> {
            return (
                this.state.selectedWorks.indexOf(work) !==-1 ?
                    <div className="col-4 work-type selected" onClick={() => this.selectWork(work, true)} key={'work'+index}><p>{work}</p></div>:
                    <div className="col-4 work-type" onClick={() => this.selectWork(work, false)} key={'work'+index}><p>{work}</p></div>
            );
        });
        return (
            <div className="container">
                <div className="row">
                    <div className="col-12 researcher">What are you working on?</div>
                    <div className="col-12 study">Select <span style={{color: '#14B8D4'}}>1</span> or more to continue</div>
                </div>
                <div className="row">
                    {usersWorks}
                    <div className="offset-2 col-8"><button className="almost-there" onClick={()=> this.setUserWork()}>Almost there</button></div>
                </div>
            </div>
        );
    }
}
export default WorkComponent;