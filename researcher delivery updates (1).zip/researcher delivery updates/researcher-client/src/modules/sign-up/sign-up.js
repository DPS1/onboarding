import React from 'react';
import './sign-up.css';
import DigitalAgency from "./digitalagency/digitalagency";
import Credential from "./credential/credential";
import Measurement from "./measurement/measurement";
import WorkComponent from "./work/work";
import WorkPlace from "./workPlace/work-place";
import Verification from "./verification/verification";
import axios from 'axios';
const config = require('../../config/app-config');

class SignUp extends React.Component {

    constructor(props) {
        super(props);
        this.handler = this.handler.bind(this);
        this.verificationHandler = this.verificationHandler.bind(this);
        this.state = {
            user:{
                type: '', name: '', email: '', password: '',
                work: {company: null, departments: null, topics: '', position: ''},
                measurement : {instrumentName: null, instrumentModel: null, sample: '', expected: ''}
            },
            activeSection: 'type',
            activeSectionProgress: '10%',
            loading: false,
            sections: ['type', 'credential', 'measurement', 'work', 'WorkPlace', 'Verification'],
            sectionsProgress: ['10%', '30%', '50%', '70%', '90%', 'Verification'],
        };
        this.handleChange = this.handleChange.bind(this);
    }

    handler(section) {
        let sectionIndex = this.state.sections.indexOf(section);
        if( sectionIndex < this.state.sections.length -1 ){
            if( section === 'WorkPlace'){
                this.register();
            }else{
                this.setState({activeSection: this.state.sections[sectionIndex+1],
                    activeSectionProgress: this.state.sectionsProgress[sectionIndex+1]});
            }

        }
        console.log(this.state.user);
    }
    handleChange(event) {
        const user = {...this.state.user};
        const fieldName = event.target.name;
        user[fieldName] = event.target.value;
        this.setState({user: user});
    }

    verificationHandler(verificationCode) {
        this.setState({ loading: true});
        axios.post(config.API.url + 'users/verify/confirm', {code: verificationCode}).then((result) => {
            if( result.data.status === 'success'){
                alert(result.data.message)
                this.setState({ loading: false, activeSection: 'type'});
            }
        }).catch( error => {
            this.setState({ loading: false});
            alert('wrong code');
            console.log(error);
        })
    }

    register = () => {
        this.setState({ loading: true});
        axios.post(config.API.url + 'users', this.state.user).then((data) => {
            this.setState({ loading: false, activeSection: 'Verification'});
        }).catch( error => {
            this.setState({ loading: false});
            console.log(error);
        })
    }

    currentSection = () => {
        switch (this.state.activeSection) {
            case 'type': return (<DigitalAgency action={this.handler} handleChange ={this.handleChange} user={this.state.user}></DigitalAgency>)
            case 'credential': return (<Credential action={this.handler} handleChange ={this.handleChange} user={this.state.user}></Credential>)
            case 'measurement': return (<Measurement action={this.handler} handleChange ={this.handleChange} user={this.state.user}></Measurement>)
            case 'work': return (<WorkComponent action={this.handler} handleChange ={this.handleChange} user={this.state.user}></WorkComponent>)
            case 'WorkPlace': return (<WorkPlace action={this.handler} handleChange ={this.handleChange} user={this.state.user}></WorkPlace>)
            case 'Verification': return (<Verification verificationHandler={this.verificationHandler}></Verification>)
            default: return null;
        }
    }
    render() {
        const completeProgress = <div className="col-3 complete">{this.state.activeSectionProgress} of your profile complete</div>
        const loader = this.state.loading ? <div className="loader loaderContainer"></div>: null;
        return (
            <div>
                <div className="container-fluid">
                    <div className="row header">
                        <div className="col-12"><img src="/assets/img/Logo.png" alt="" className="img-fluid logo"/></div>
                    </div>
                    <div className="row">{completeProgress} <div className="col-9"></div></div>
                </div>
                {loader}
                {this.currentSection()}
            </div>
        );
    }
}
export default SignUp;