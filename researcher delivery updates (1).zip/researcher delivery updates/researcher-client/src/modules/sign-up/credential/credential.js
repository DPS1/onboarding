import React from 'react';
import './credential.css';
import $ from 'jquery';

class Credential extends React.Component {
    constructor(props) {
        super(props);
        this.state = {...props.user};
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    chngimg = () =>{
        var img = document.getElementById('eye').src;
        if (img.indexOf('/assets/img/eye-slash.png') != -1) {
            document.getElementById('eye').src = '/assets/img/eye.png';
            document.getElementById('pass').type = 'text';
        } else {
            document.getElementById('eye').src = '/assets/img/eye-slash.png';
            document.getElementById('pass').type = 'password';
        }
    }
    handleSubmit(event) {
        this.props.action('credential');
        event.preventDefault();
    }
    handleChange(event) {
        const fieldName = event.target.name;
        const fieldValue = event.target.value;
        this.setState({[fieldName]: fieldValue});
        this.props.handleChange(event);
    }
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-12 researcher">Lets set credentials</div>
                    <div className="col-12 study">Share where you work and what you're studying to best results</div>
                </div>
                <div className="row credential">
                    <div className="col-12">
                        <form onSubmit={this.handleSubmit}>
                            <div className="input-box">
                                <input type="text" placeholder="" value={this.state.name} onChange={this.handleChange} name='name'
                                       className="input" required=""/>
                                 <label>First Name</label>
                            </div>
                            {/*<div className="input-box">
                                <input type="text" placeholder="" value={this.state.name}  className="input" required=""/>
                                    <label>Last Name</label>
                            </div>*/}
                            <div className="input-box">
                                <input type="text" placeholder="" value={this.state.email}  onChange={this.handleChange}
                                       className="input"  name='email' required=""/>
                                <label>Email</label>
                            </div>
                            <div className="input-box">
                                <input type="password" placeholder="" value={this.state.password} onChange={this.handleChange} name='password'
                                       className="input" required="" id="pass" />
                                    <label>Password</label>
                                    <img src="/assets/img/eye-slash.png" alt="" className="eye" id="eye" onClick={() => this.chngimg()}/>
                            </div>
                            <div className="accept">
                                Accept <a href="#">privacy</a> &amp; <a href="#">terms</a> &nbsp;&nbsp;<input
                                type="checkbox" name="checkbox" value="check" id="agree" className="checkbox"/>
                            </div>
                            <input type="submit" className="input submit" value="Continue"/>
                        </form>
                    </div>
                </div>
            </div>
        );
    }
}
export default Credential;