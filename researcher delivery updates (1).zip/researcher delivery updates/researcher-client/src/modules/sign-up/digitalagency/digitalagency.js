import React from 'react';
import './digitalagency.css';

class DigitalAgency extends React.Component {
    constructor(props) {
        super(props);
    }
    setUserType = (type) => {
        const user = {...this.props.user};
        user.type = type;
        this.props.handleChange({target: {name: 'type', value: type}});
        this.props.action('type');
    }
    render() {
        return (
                <div className="container">
                    <div className="row">
                        <div className="col-12 researcher">What Type Researcher are you?</div>
                        <div className="col-8 select">select one of three options below</div>
                        <div className="col-7"></div>
                    </div>
                    <div className="row researcher-option" onClick={()=> this.setUserType('Academic')}>
                        <div className="col-3">
                            <img src="/assets/img/img-1.png" alt="" className=" research-option-img"/>
                        </div>
                        <div className="col-6">
                            <p className="heading">Academic or Student</p>
                            <p className="eg">e.g. faculty member, student, researcher at university, librarian,
                                institute of TTO</p>
                        </div>
                        <div className="col-3 arrow">
                            <img src="/assets/img/right-arrow.png" alt="" className="right-arrow"/>
                        </div>
                    </div>
                    <div className="row researcher-option" onClick={()=> this.setUserType('Cooperate')}>
                        <div className="col-3">
                            <img src="/assets/img/img-2.png" alt="" className=" research-option-img"/>
                        </div>
                        <div className="col-6">
                            <p className="heading">Cooperate, Government, NGO</p>
                            <p className="eg">e.g. product developer, applied research, Technology developer</p>
                        </div>
                        <div className="col-3 arrow">
                            <img src="/assets/img/right-arrow.png" alt="" className="right-arrow"/>
                        </div>
                    </div>
                    <div className="row researcher-option" onClick={()=> this.setUserType('Other')}>
                        <div className="col-3">
                            <img src="/assets/img/img-3.png" alt="" className=" research-option-img"/>
                        </div>
                        <div className="col-6">
                            <p className="heading">Other</p>
                            <p className="eg">e.g. independent researcher, journalist, retired researcher, university
                                aluminus</p>
                        </div>
                        <div className="col-3 arrow">
                            <img src="/assets/img/right-arrow.png" alt="" className="right-arrow"/>
                        </div>
                    </div>
                    <div className="row login">
                        <div className="col-6">Already using our services? <a href="#">log in</a></div>
                    </div>
                </div>
        );
    }
}
export default DigitalAgency;