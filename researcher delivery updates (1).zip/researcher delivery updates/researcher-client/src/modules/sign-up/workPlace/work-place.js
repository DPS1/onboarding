import React from 'react';
import './work-place.css';

class WorkPlace extends React.Component {
    constructor(props) {
        super(props);
        this.state = {...props.user.work};
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    handleSubmit(event) {
        this.props.action('WorkPlace');
        event.preventDefault();
    }
    handleChange(event) {
        const fieldName = event.target.name;
        const fieldValue = event.target.value;
        this.setState({[fieldName]: fieldValue});
        this.props.handleChange({target: {name: 'work', value: this.state}});
    }
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-12 researcher" style={{textAlign: 'center'}}>Tell us about where your work</div>
                    <div className="col-12 study measurement-sub " style={{textAlign: 'center'}}>You will be able to change all preferences in settings once logged in</div>
                    <div className="col-7"></div>
                </div>
                <div className="row credential" style={{marginTop: 2+'%'}}>
                    <div className="col-12">
                        <form action="email.html"  onSubmit={this.handleSubmit}>
                            <div className="input-box">
                                <input type="text" placeholder="" className="input" required=""
                                       value={this.state.position} onChange={this.handleChange} name='position'/>
                                    <label>Position</label>
                            </div>
                            <img src="/assets/img/qmark.png" alt="" className="qmark qmark-right" data-toggle="tooltip"
                                 data-placement="top" title="Image of Expected Plot"/>
                                <div className="input-box">
                                    <input type="text" placeholder="" className="input" required=""
                                           value={this.state.company} onChange={this.handleChange} name='company'/>
                                        <label>Institution/Company</label>
                                </div>
                                <img src="/assets/img/qmark.png" alt="" className="qmark qmark-right" data-toggle="tooltip"
                                     data-placement="top" title="Image of Expected Plot"/>
                                    <div className="input-box">
                                        <input type="text" placeholder="" className="input" required=""
                                               value={this.state.departments} onChange={this.handleChange} name='departments'/>
                                            <label>Department/Lab</label>
                                    </div>
                                    <img src="/assets/img/qmark.png" alt="" className="qmark qmark-right"
                                         data-toggle="tooltip" data-placement="top" title="Image of Expected Plot"/>
                                        <input type="submit" className="input submit" value="Continue"/>

                        </form>
                    </div>
                </div>
                <div className=" col-12 skip"><a href="email.html">skip &gt;</a></div>
            </div>
        );
    }
}
export default WorkPlace;