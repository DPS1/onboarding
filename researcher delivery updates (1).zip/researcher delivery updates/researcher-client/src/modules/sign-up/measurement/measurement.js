import React from 'react';
import './measurement.css';
import $ from 'jquery';

class Measurement extends React.Component {
    dropRef = React.createRef();
    dropRef2 = React.createRef();
    constructor(props) {
        super(props);
        this.state = {instrumentName: '', instrumentModel: '', sample: '', expected: '',
            dragging: false, dragging2: false, selectedSample: '', selectedExpected: ''};
        this.state.measurementList = [
            'XRD: Bragg–Brentano theta-2 theta 9', 'UV-Vis-NIR 6', 'PLD channels 6', 'Raman Scattering 6', 'EP: Galvanostat (CP) 5', 'Report 5',
        'jV Solar Simulator 5', 'EP: Open Circuit Voltage (OCP) 4', 'Photo_lithography 4', 'Light intensity vs time 4', 'AFM 4',
        'EP: Cycle Life Plot (CLP) 4', 'Transmittance 4', 'Image 4', 'SEM 4', 'critical dimension (CD) 4', 'EP: Cyclic Voltammetry (CV) 4',
        'Reflectance', 'EP: IR compensation (ZIR) 3', 'EP: Cyclic Voltametry Advanced (CVA)', 'other'];
        this.state.instrumentList = [
            'BioLogic SP-150 ONLY', 'BIU_combi_Lab Optical scanner 7', 'BioLogic VMP3 7', 'BioLogic SP-50 7', 'PREVAC PLD HZB - EE-IF 6',
            'Rigaku Smartlab 3KW 6', 'Bruker D8 ADVANCE 6', 'National Electrostatics Corporation (NEC) The 1.7 MV tandem Pelletron: 5SDH 5',
        'Generic image generator 5', 'Horiba Jobin Yvon Corporation LabRAM HR + Raman 5', 'Generic signal generator 4',
        'Generic ASCII 3', 'FLUXiM PAIOS', 'KP Technology Ltd. ASKP150200 + SPV + APS ONLY', 'FEI Magellan 400L 3',
        'Princeton Instruments SP-2500 3', 'Generic lithography process 3', 'PARC 273a Potentiostat/Galvanostat 3',
        'Neocera Pioneer 120 Advanced PLD System 3', "J'asco V-570 3z", 'other'
    ]
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.onUploaderChange = this.onUploaderChange.bind(this);
    }
    reInitDragAndDrop = () => {
        this.dragCounter = 0;
        this.dragCounter2 = 0;
        let div = this.dropRef.current
        let div2 = this.dropRef2.current
        div.addEventListener('dragenter', this.handleDragIn)
        div.addEventListener('dragleave', this.handleDragOut)
        div.addEventListener('dragover', this.handleDrag)
        div.addEventListener('drop', this.handleDrop)

        div2.addEventListener('dragenter', this.handleDragIn)
        div2.addEventListener('dragleave', this.handleDragOut)
        div2.addEventListener('dragover', this.handleDrag)
        div2.addEventListener('drop', this.handleDrop)
    }
    componentDidMount() {
        $('[data-toggle="tooltip"]').tooltip()
        this.reInitDragAndDrop();
    }
    // and or
    componentDidUpdate() {
        if(!this.state.instrumentName && !this.state.instrumentModel ){
            this.reInitDragAndDrop();
        }
    }
    componentWillUnmount() {
        let div = this.dropRef.current
        let div2 = this.dropRef2.current
        if( div ){
            div.removeEventListener('dragenter', this.handleDragIn)
            div.removeEventListener('dragleave', this.handleDragOut)
            div.removeEventListener('dragover', this.handleDrag)
            div.removeEventListener('drop', this.handleDrop)
        }

        if ( div2 ){
            div2.removeEventListener('dragenter', this.handleDragIn)
            div2.removeEventListener('dragleave', this.handleDragOut)
            div2.removeEventListener('dragover', this.handleDrag)
            div2.removeEventListener('drop', this.handleDrop)
        }
    }

    handleSubmit(event) {
        this.props.action('measurement');
        event.preventDefault();
        // console.log(this.state)
    }
    handleChange(event) {
        const fieldName = event.target.name;
        const fieldValue = event.target.value;
        this.setState({[fieldName]: fieldValue});
        let measurement = {instrumentName: this.state.instrumentName, instrumentModel: this.state.instrumentModel,
            sample: this.state.sample, expected: this.state.expected}
        this.props.handleChange({target: {name: 'measurement', value: measurement}});
        if( (fieldName === 'instrumentName' || fieldName === 'instrumentModel') && fieldValue){
            this.setState({sample: '', expected: ''});
        }
        if(fieldName === 'selectedSample'){
            this.setState({sample: fieldValue === 'other' ? '' : fieldValue})
        }
        if(fieldName === 'selectedExpected'){
            this.setState({expected: fieldValue === 'other' ? '' : fieldValue})
        }
        if((fieldName === 'instrumentName' || fieldName === 'instrumentModel') && fieldValue ){
            this.setState({sample: '', expected: '', sampleFile: '', expectedFile: ''});
        }


        measurement = {instrumentName: this.state.instrumentName, instrumentModel: this.state.instrumentModel,
            sample: this.state.sample, expected: this.state.expected}
        this.props.handleChange({target: {name: 'measurement', value: measurement}});
    }
    onUploaderChange = event => {
        const fieldName = event.target.name;
        const ref = this;
        if (event.target.files && event.target.files[0]) {
            ref.setState({[fieldName + 'File']: event.target.files[0].name});
            var reader = new FileReader();
            reader.onload = (event: any) => {
                ref.setState({[fieldName]: event.target.result});
                const measurement = {instrumentName: ref.state.instrumentName, instrumentModel: ref.state.instrumentModel,
                    sample: ref.state.sample, expected: ref.state.expected};
                ref.props.handleChange({target: {name: 'measurement', value: measurement}});
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    }
    openFileUploader = (id) => $(id).click();

    handleDrag = (e) => {
        e.preventDefault()
        e.stopPropagation()
    }
    handleDragIn = (e) => {
        e.preventDefault()
        e.stopPropagation()
        if ( e.currentTarget.id === 'div1'){this.dragCounter++}
        else{ this.dragCounter2++ }
        if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
            if ( e.currentTarget.id === 'div1'){
                this.setState({dragging: true})
            }else{
                this.setState({dragging2: true})
            }
        }
    }
    handleDragOut = (e) => {
        e.preventDefault()
        e.stopPropagation()
        if ( e.currentTarget.id === 'div1'){
            this.dragCounter--
            if (this.dragCounter > 0) return
            this.setState({dragging: false})
        }
        else{
            this.dragCounter2--
            if (this.dragCounter2 > 0) return
            this.setState({dragging2: false})
        }
    }

    handleDrop = (e) => {
        e.preventDefault()
        e.stopPropagation()
        if ( e.currentTarget.id === 'div1'){
            this.setState({dragging: false})
        }else{
            this.setState({dragging2: false})
        }
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            // this.props.handleDrop(e.dataTransfer.files)
            const fieldName = e.currentTarget.id === 'div1' ? 'sample' : 'expected';
            const ref = this;

                ref.setState({[fieldName + 'File']: e.dataTransfer.files[0].name});
                var reader = new FileReader();
                reader.onload = (event: any) => {
                    ref.setState({[fieldName]: event.target.result});
                    const measurement = {instrumentName: ref.state.instrumentName, instrumentModel: ref.state.instrumentModel,
                        sample: ref.state.sample, expected: ref.state.expected};
                    ref.props.handleChange({target: {name: 'measurement', value: measurement}});
                }
                reader.readAsDataURL(e.dataTransfer.files[0]);



            e.dataTransfer.clearData()
            if ( e.currentTarget.id === 'div1'){
                this.dragCounter = 0
            }else{
                this.dragCounter2 = 0
            }
        }
    }
    render() {
        const sampleList  = this.state.measurementList.map((item, index)=> {
            return ( <option value={item}>{item}</option>  );
        });
        const InstrumentList  = this.state.instrumentList.map((item, index)=> {
            return ( <option value={item}>{item}</option>  );
        });

        const sampleOther  = this.state.selectedSample === 'other' ? <div className="input-box">
            <input type="text" className="input" required=""
                   value={this.state.sample} onChange={this.handleChange} name='sample'/>
        </div>: null;


        const expectedOther  = this.state.selectedExpected === 'other' ? <div className="input-box">
            <input type="text" className="input" required=""
                   value={this.state.expected} onChange={this.handleChange} name='expected'/>
        </div>: null;





        const sampleUploader = this.state.instrumentName || this.state.instrumentModel ?
            <div className="row">
                <div className="col-6">
                    <label htmlFor="selectedSample">Measurement</label>
                    <select className="form-control" id="selectedSample" name='selectedSample'
                            value={this.state.selectedSample} onChange={this.handleChange}>
                        {sampleList}
                    </select>
                    {sampleOther}
                </div>
                <div className="col-6">
                    <label htmlFor="selectedExpected">Instrument</label>
                    <select className="form-control" id="selectedExpected" name='selectedExpected'
                            value={this.state.selectedExpected} onChange={this.handleChange}>
                        {InstrumentList}
                    </select>
                    {expectedOther}
                </div>
            </div> :


            <div className="row">
                <div className="col-6">
                    <button type="button" className="no-bg" data-toggle="tooltip" data-placement="left" title="Measurement Sample">
                        <img src="/assets/img/qmark.png" alt="" className="qmark"/>
                    </button>
                    <div className={'upload ' + (this.state.dragging? "uploadDragOver":"")}  id='div1'
                         ref={this.dropRef}>Measurement<br/>File Sample<br/>
                        <button onClick={() => this.openFileUploader('#fileSample')}>Upload</button>
                        <input type='file' id='fileSample' onChange={this.onUploaderChange} name='sample'
                               style={{display: 'none'}}/>
                        <span style={{display: 'block'}}>{this.state['sampleFile'] || ''}</span>
                    </div>
                </div>
                <div className="col-6">
                    <button type="button" className="no-bg " data-toggle="tooltip" data-placement="top" title="Image of Expected Plot">
                        <img src="/assets/img/qmark.png" alt="" className="qmark"/>
                    </button>
                    <div className={'upload ' + (this.state.dragging2? "uploadDragOver":"")} id='div2'
                         ref={this.dropRef2}>Image of<br/>Expected Plot<br/>
                        <button onClick={() => this.openFileUploader('#fileExpected')}>Upload</button>
                        <input type='file' id='fileExpected' onChange={this.onUploaderChange} name='expected'
                               style={{display: 'none'}}/>
                        <span style={{display: 'block'}}>{this.state['expectedFile'] || ''}</span>
                    </div>
                </div>
            </div>


        return (
            <div className="container">
                <div className="row">
                    <div className="col-12 researcher" style={{textAlign: 'center'}}>Typical measurements type?</div>
                    <div className="col-12 study measurement-sub " style={{textAlign: 'center'}}>
                        You will be able to change all preferences in settings once logged in
                    </div>
                    <div className="col-7"></div>
                </div>
                {sampleUploader}
                <div className="row credential" style={{marginTop: 2+'%'}}>
                    <div className="col-12">
                        <form onSubmit={this.handleSubmit}>
                            <div className="input-box">
                                <input type="text" className="input" required=""
                                       value={this.state.instrumentName} onChange={this.handleChange} name='instrumentName'/>
                                <label>Instrument name</label>
                            </div>
                            <img src="/assets/img/qmark.png" alt="" className="qmark qmark-right" data-toggle="tooltip"
                                 data-placement="top" title="Image of Expected Plot"/>
                                <div className="input-box">
                                    <input type="text" className="input" required=""
                                           value={this.state.instrumentModel} onChange={this.handleChange} name='instrumentModel'/>
                                    <label>Instrument model</label>
                                </div>
                                <img src="/assets/img/qmark.png" alt="" className="qmark qmark-right" data-toggle="tooltip"
                                     data-placement="top" title="Image of Expected Plot"/>
                                    <input type="submit" className="input submit" value="Continue"/>
                        </form>
                    </div>
                </div>
                <div className="col-12 skip"><a href="work.html">skip &gt;</a></div>
            </div>
        );
    }
}
export default Measurement;