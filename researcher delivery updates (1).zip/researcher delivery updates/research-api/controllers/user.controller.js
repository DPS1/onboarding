const userModel = require('../models/user.model');
const usersVerificationModel = require('../models/userVerification.model');
const userResetPasswordModel = require('../models/resetPassword.model');

var nodeMailer = require('nodemailer');
const bcrypt = require('bcryptjs');
var bcryptSalt = bcrypt.genSaltSync(10);
const config = require('../config/app-config');

// Create and Save a new user
exports.create = (req, res) => {
    // Validate request
    if(!req.body.email || !req.body.password || !req.body.name) {
        return res.status(400).send({message: "user email, password and name can not be empty"});
    }

    const userObject = new userModel({...req.body});
    bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(userObject.password, salt, (err, hash) => {
            if(err) throw err;
            userObject.password = hash;
            userObject.save()
                .then(user => {
                        var code = "";
                        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                        for (var i = 0; i < 6; i++) {
                            code += possible.charAt(Math.floor(Math.random() * possible.length));
                        }
                        const userVerificationObject = new usersVerificationModel({userID: user._id, email: user.email, code: code});
                        userVerificationObject.save()
                            .then(data => {
                                var transporter = nodeMailer.createTransport({
                                        host: config.emailConfig.host, port: config.emailConfig.port,
                                        auth: {user: config.emailConfig.email, pass: config.emailConfig.password}
                                });
                                var mailOptions = {
                                    from:config.emailConfig.email, // sender address
                                    to:  data.email, // list of receivers
                                    subject: 'Account Verification', // Subject line
                                    text: 'Hello,'+user.name, // plain text body
                                    html: '<b>Verification Code =  </b>' + code
                                };
                                transporter.sendMail(mailOptions, (error, info) => {
                                    if (error) {
                                        console.log(error);
                                        res.send({status:'error'});
                                    }
                                });
                                res.send(user);
                            })
                            .catch(err => {
                                    res.status(500).send({
                                    message: err.message || "Some error occurred while send user verification email."
                                });
                            });
                     })
                .catch(err => {
                        res.status(500).send({
                        message: err.message || "Some error occurred while creating the user."
                    });
                });
        });
    });
};


// Update
exports.updateUser = (req, res) => updateUserRequest(req.body.user, res);


// delete
exports.deleteUser = (req, res) => {
    req.body.user.deleted =true;
    req.body.user.status = 'deleted';
    updateUserRequest(req.body.user, res);
};


updateUserRequest = (user, res)=>{
    if(notValidateUserData(user)) {
        return res.status(400).send({message: "missing select users to delete"});
    }
    userModel.findByIdAndUpdate(user._id, user, {new: true}).then(user => {
        if(!user) {return res.status(404).send({message: "user not found with id " + user._id});}
        res.send(user);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({message: "user not found with id " + user._id});
        }
        return res.status(500).send({message: "Error updating user with id " + user._id});
    });
}
notValidateUserData = (user) => !user.email || !user.password || !user.name || !user.type || !user.status || !user.measurement.sample ||
    !user.measurement.expected || !user.work.topics || !user.work.position;



// get all
exports.findAll = (req, res) => {
    const pageNo = req.query.pageNo ? parseInt(req.query.pageNo) : 1;
    const size = req.query.size ? parseInt(req.query.size): 10;
    userModel.count().then(totalCount => {
        userModel.find({ deleted: false },{},{skip : size * (pageNo - 1), limit: size})
            .then(users => res.send({users: users, pages: Math.ceil(totalCount / size)}))
            .catch(err => res.status(500).send({message: err.message || "Some error occurred while retrieving users."}));

    }).catch(err => res.status(500).send({message: err.message || "Some error occurred while retrieving users."}));
};

// get all
exports.searchUsers = (req, res) => {
    const searchParam = req.query.search;
    userModel.find({ deleted: false, name: {'$regex': req.query.search}},{},{})
            .then(users => res.send({users: users}))
            .catch(err => res.status(500).send({message: err.message || "Some error occurred while retrieving users."}));
};


//verify Confirm
exports.verifyConfirm = (req, res) => {
    // Validate Request
    // if(!req.body.code || !req.body.userID) {return res.status(400).send({message: "userID, verification code can not be empty"});}
    usersVerificationModel.findOne({'code': req.body.code}).then(userVerificationData => {
            userModel.updateOne({ _id: userVerificationData.userID}, {$set: {status: 'verified'}})
                .then(user => {
                    if(!user) {return res.status(404).send({message: "user not found with id " + req.body.userID});}
                     res.send({status: 'success', message: "Account verified successfully"});
                }).catch(err => {
                        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
                        return res.status(404).send({message: "user not found with id " + req.body.userID});
                    }
                    return res.status(500).send({message: "Could not verify user with id " + req.body.userID});
                });
        }).catch(err => {
                res.status(500).send({message: err.message || "Some error occurred while confirming user verification."});
        });
};
