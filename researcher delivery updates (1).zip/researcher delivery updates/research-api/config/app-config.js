module.exports = {
    emailConfig:{
        email: 'freelancer.app600@gmail.com',
        password: 'FreelancerApp600',
        host: 'smtp.gmail.com',
        port: 465
    }

};