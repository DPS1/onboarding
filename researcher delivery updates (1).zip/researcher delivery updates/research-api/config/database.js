module.exports = {
    database: 'mongodb://localhost:27017/researcher',
    // database: 'mongodb://behaviorism:behaviorism123@ds229701.mlab.com:29701/behaviorism',
    secret: 'yoursecret'
};