const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const UserSchema = mongoose.Schema({
  name: {type: String, required: true},
  email: {type: String, required: true, unique: true},
  password: {type: String, required: true},
  photo: {type: String, required: false, default: null},
  type: {type: String, required: true},
  status: {type: String, required: true, default: 'not verified'},
  deleted: {type: Boolean, required: false, default: false},
  measurement : {
        sample:{type: String, required: false, default: null},
        expected: {type: String, required: false, default: null},
        instrumentName:{type: String, required: false, default: null},
        instrumentModel:{type: String, required: false, default: null},
  },
  work:  {
      topics:{type: String, required: true},
      position: {type: String, required: true},
      company:{type: String, required: false, default: null},
      departments:{type: String, required: false, default: null},
  },
});
module.exports = mongoose.model('users', UserSchema);

module.exports.comparePassword = function(candidatePassword, hash, callback){
    bcrypt.compare(candidatePassword, hash, (err, isMatch) => {
        if(err) throw err;
         callback(null, isMatch);
    });
};