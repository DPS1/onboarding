const mongoose = require('mongoose');

const UserResetPasswordSchema = mongoose.Schema({
  email: {type: String, required: true},
  date: {type: Date, default: Date.now},
  code: {type: String, required: true},
  used: {type: Boolean, default: false},
});
module.exports = mongoose.model('users_reset_password', UserResetPasswordSchema);
