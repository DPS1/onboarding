const mongoose = require('mongoose');

const UserVerificationSchema = mongoose.Schema({
  userID: {type: String, required: true},
  email: {type: String, required: true},
  date: {type: Date, default: Date.now},
  code: {type: String, required: true},
  verified: {type: Boolean, default: false},
});
module.exports = mongoose.model('users_verification', UserVerificationSchema);
