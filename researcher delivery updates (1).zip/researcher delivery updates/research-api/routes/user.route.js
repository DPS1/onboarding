const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');

// Register
router.post('/', userController.create);

// update
router.put('/', userController.updateUser);

// delete
router.put('/delete', userController.deleteUser);

// get all
router.get('/', userController.findAll);

// search
router.get('/search', userController.searchUsers);

// verify confirm
router.post('/verify/confirm', userController.verifyConfirm);


module.exports = router;