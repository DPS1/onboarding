module.exports = {
    API:{
        url: 'http://localhost:3000/'
    }
};