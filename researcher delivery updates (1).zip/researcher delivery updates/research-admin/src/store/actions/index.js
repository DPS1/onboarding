export function addArticle(payload) {
    return { type: "ADD_ARTICLE", payload }
};