const initialState = {
    articles: []
};
function rootReducer(state = initialState, action) {
    return state;
};
export default rootReducer;